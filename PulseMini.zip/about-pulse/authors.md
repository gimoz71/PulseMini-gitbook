# Authors

**Gabriele S.**

* Founder, Architect of the Pulse Method
* Lead Designer of the Pulse Engines
* WaveLabs — Strategic Market Systems

&

**Astra AI.**

* WaveLabs Behavioural Systems Unit
* Modelling, Structural Research, Engine Co-Design
* Made with passion by WaveLabs

Say [**@hello**](mailto:hello@wavelabs.fi)

<br>
